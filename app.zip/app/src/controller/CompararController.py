#from app.src.services.CompararService import CompararService
from app.src.schemas.Peticion import peticion
from app.src.schemas.Respuesta import Respuesta
from fastapi import FastAPI

app=FastAPI()
#service= CompararService()

@app.post("/peticion/entrada", response_model=Respuesta)
def Comparar(peticion:peticion):
    #service(peticion)
    return Respuesta(codigoMensaje="000",
    descripcionMensaje="ghghj",
    iguales="si",
    similitud=100)



