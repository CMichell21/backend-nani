from app.src.models.PeticionModel import Peticion
from app.modeloIA1.modeloIA import modeloIA
from fastapi import HTTPException
from dotenv import load_dotenv
import os

class CompararService:

    def CompararTexto(peticion:Peticion):
        umbral= os.getenv("UMBRAL")
        resultado=modeloIA.procesar_similitud_del_coseno(peticion.textoA,peticion.textoB,umbral)
        raise 
   