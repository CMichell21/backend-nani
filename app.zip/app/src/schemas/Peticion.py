from pydantic import BaseModel, Field, field_validator
from typing import Optional, Literal

class peticion(BaseModel):
    aplicacion:str=Field(max_length=20) #
    servicio:int
    usuario:Optional[str]= Field(
        default=None,
        max_length=30
    )
    terminal:Optional[str]= Field(
        default=None,
        max_length=30
    )
    textoA:str=Field(max_length=32000)
    textoB:str=Field(max_length=32000)


    @field_validator("servicio")
    @classmethod
    def validar_servicio(cls, v: int) -> int:
        if len(str(abs(v))) > 4:
            raise ValueError("longitud de numero invalida")
        return v